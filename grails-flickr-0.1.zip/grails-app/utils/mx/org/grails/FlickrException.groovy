package mx.org.grails

class FlickrException extends RuntimeException{
  String message
}
